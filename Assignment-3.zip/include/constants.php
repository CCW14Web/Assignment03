<?php
/*
  Document   : Constants.php
  Created on : Mar 1/ 2014,
  Author     : Cherry Jose
  Description: Constant for database
  
 */
$DBADD = "localhost";
$DBUNAME = "root";
$DBPASS = "";
$DB="dbsurvey";

?>