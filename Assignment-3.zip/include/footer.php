<?php/*
Document   : Footer.php
Created on : 
Author     : 
Description: Footer Page

*/
?>
<footer class="row-fluid ">     <!-- Footer div !-->
    <div class="span5">

    </div>
    <div class="span6">
        <p>
            &copy Copyright2014 <a href="" target="_blank">E-Survey</a>
            <br>
            <a href="terms.php">Terms Of Use</a> | <a href="privacy.php">Privacy</a>
        </p>
    </div>

</footer>                       <!-- Ends the footer !-->